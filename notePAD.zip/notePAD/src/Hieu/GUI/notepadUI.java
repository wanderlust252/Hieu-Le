/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hieu.GUI;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

/**
 *
 * @author Admin
 */
public class notepadUI extends JFrame {
    int flag = 0;
    boolean checkBOLD=true;
    boolean checkITALIC = true;
    JMenuBar bar;
    JMenu mnuFILE, mnuEDIT;
    JMenuItem itemNew, itemOpen, itemSave, itemExit,itemFont,itemFont1;
    JTextArea txtArea;

    JFileChooser chonFile = new JFileChooser();

    public notepadUI(String title) {
        super(title);
        addControls();
        addEvents();

    }

    private void addControls() {
        bar = new JMenuBar();
        this.setJMenuBar(bar);
        mnuFILE = new JMenu("FILE");
        mnuEDIT = new JMenu("EDIT");
        bar.add(mnuFILE);
        bar.add(mnuEDIT);
        ////////// Thêm đề mục cho tag FILE
        itemNew = new JMenuItem("New");
        itemOpen = new JMenuItem("Open");
        itemExit = new JMenuItem("Exit");
        itemSave = new JMenuItem("Save");
        mnuFILE.add(itemNew);
        mnuFILE.add(itemOpen);
        mnuFILE.add(itemSave);
        mnuFILE.addSeparator();
        mnuFILE.add(itemExit);
        //////////// Thêm đề mục cho tag EDIT
        itemFont = new JMenuItem("BOLD");
        mnuEDIT.add(itemFont);
        Container con = this.getContentPane();
        con.setLayout(new BorderLayout());
        itemFont1 = new JMenuItem("ITALIC");
        mnuEDIT.add(itemFont1);
        txtArea = new JTextArea();
        txtArea.setFont(new Font("Consolas", Font.PLAIN, 20));
        JScrollPane scArea = new JScrollPane(txtArea,
                JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS
        );
        con.add(scArea, BorderLayout.CENTER);
    }

    private void addEvents() {
        ///////EXIT
        itemExit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xulyThoat();
            }
        });
        ////////tạo mới
        itemNew.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xulyNew();
            }
        });
        //////// mở file
        itemOpen.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xulyMoFile();
            }
        });
        //////// lưu file
        itemSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xulyLuuFile();
            }
        });
        ///////  Chỉnh font
        itemFont.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(checkBOLD == true){
                    txtArea.setFont(new Font("Consolas", flag= flag +1, 20));
                    checkBOLD = false;
                }
                else{
                    txtArea.setFont(new Font("Consolas", flag= flag -1, 20));
                    checkBOLD = true;
                }
            }
        });
        itemFont1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(checkITALIC == true){
                    txtArea.setFont(new Font("Consolas", flag= flag +2, 20));
                    checkITALIC = false;
                }
                else{
                    txtArea.setFont(new Font("Consolas", flag= flag -2, 20));
                    checkITALIC = true;
                }
            }
        });
    }

    private void xulyLuuFile() {
        String data = txtArea.getText();

        if (chonFile.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
            File selectedFile = chonFile.getSelectedFile();
            if (selectedFile.exists()) {//nếu file đã tồn tại
                int ret = JOptionPane.showConfirmDialog(null, "bạn có muốn ghi đề file này không?", "Trượt nguyên lý 1", JOptionPane.YES_NO_OPTION);
                if (ret == JOptionPane.NO_OPTION) {
                    return;
                }
            }
            try {
                PrintWriter pw = new PrintWriter(new FileOutputStream(selectedFile));
                pw.println(data);
                pw.close();
                JOptionPane.showMessageDialog(null, "lưu file thành công");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void xulyMoFile() {
        if (chonFile.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
            File selectedFile = chonFile.getSelectedFile(); //lấy ra file đc chọn
            try {
                BufferedReader br = new BufferedReader(
                        new InputStreamReader(
                                new FileInputStream(selectedFile), "UTF-8"));
                String line = br.readLine();
                StringBuilder builder = new StringBuilder();
                while (line != null) {
                    builder.append(line + "\n");
                    line = br.readLine();
                }
                txtArea.setText(builder.toString());
                br.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    private void xulyNew() {
        int re = JOptionPane.showConfirmDialog(null,
                "Bạn muốn lưu file trước khi tạo mới không?",
                "Trượt nguyên lý 1",
                JOptionPane.YES_NO_OPTION
        );
        if (re == JOptionPane.NO_OPTION) {
            txtArea.setText("");
        } else if (re == JOptionPane.YES_OPTION) {
            xulyLuuFile();
        } else {
            return;
        }
    }

    private void xulyThoat() {
        int re = JOptionPane.showConfirmDialog(null,
                "Bạn có chắc chắn muốn thoát chương trình không?",
                "Trượt nguyên lý 1",
                JOptionPane.YES_NO_OPTION);
        if (re == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    public void showWindow() {
        this.setSize(900, 600);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

}
